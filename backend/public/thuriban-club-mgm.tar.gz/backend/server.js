const express = require('express');
const cors = require('cors');
const path = require('path');

const app = express();
app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

// ── Users (auth) ────────────────────────────────────────────────
const users = [
  { id: 1, username: 'admin',   password: 'admin123',   name: 'Admin',    role: 'Administrator' },
  { id: 2, username: 'manager', password: 'manager123', name: 'Su Su',    role: 'Manager'       },
  { id: 3, username: 'aung',    password: 'aung123',    name: 'Aung Kyaw',role: 'Member'        },
];

app.post('/api/login', (req, res) => {
  const { username, password } = req.body || {};
  const user = users.find(u => u.username === username && u.password === password);
  if (!user) return res.status(401).json({ success: false, message: 'Invalid username or password.' });
  const { password: _pw, ...safe } = user;
  res.json({ success: true, user: safe });
});

// ── In-memory data ──────────────────────────────────────────────
let members = [
  { id: 1, name: 'Aung Kyaw',  email: 'aung@thuriban.com',   phone: '+95 9 123 456 789', role: 'Admin',   status: 'Active',   joinDate: '2024-01-15' },
  { id: 2, name: 'Nay Lin',    email: 'naylin@thuriban.com', phone: '+95 9 987 654 321', role: 'Member',  status: 'Active',   joinDate: '2024-02-20' },
  { id: 3, name: 'Su Su',      email: 'susu@thuriban.com',   phone: '+95 9 456 789 123', role: 'Manager', status: 'Active',   joinDate: '2024-03-10' },
  { id: 4, name: 'Kyaw Zin',   email: 'kyawzin@thuriban.com',phone: '+95 9 321 654 987', role: 'Member',  status: 'Inactive', joinDate: '2024-04-05' },
  { id: 5, name: 'Mya Mya',    email: 'myamya@thuriban.com', phone: '+95 9 654 321 789', role: 'Member',  status: 'Active',   joinDate: '2024-05-12' },
  { id: 6, name: 'Zaw Win',    email: 'zawwin@thuriban.com', phone: '+95 9 111 222 333', role: 'Member',  status: 'Active',   joinDate: '2025-01-08' },
];

let tasks = [
  { id: 1, title: 'Club Annual Meeting',       description: 'Prepare agenda and materials',         status: 'todo',       priority: 'High',   assignee: 'Aung Kyaw', dueDate: '2026-06-15' },
  { id: 2, title: 'Membership Drive Campaign', description: 'Design and run recruitment campaign',  status: 'inprogress', priority: 'Medium', assignee: 'Su Su',     dueDate: '2026-06-20' },
  { id: 3, title: 'Update Club Website',       description: 'Refresh content and photos',           status: 'inprogress', priority: 'Low',    assignee: 'Nay Lin',   dueDate: '2026-06-25' },
  { id: 4, title: 'Financial Report Q1',       description: 'Prepare quarterly financial summary',  status: 'done',       priority: 'High',   assignee: 'Kyaw Zin',  dueDate: '2026-05-30' },
  { id: 5, title: 'Sports Event Planning',     description: 'Organize the annual sports day',       status: 'todo',       priority: 'Medium', assignee: 'Mya Mya',   dueDate: '2026-07-01' },
  { id: 6, title: 'Club Newsletter',           description: 'Write and distribute monthly letter',  status: 'done',       priority: 'Low',    assignee: 'Zaw Win',   dueDate: '2026-05-20' },
];

let messages = [
  { id: 1, sender: 'Aung Kyaw', avatar: 'AK', text: "Good morning everyone! Ready for today's meeting?",       time: '09:00 AM', date: '2026-06-07' },
  { id: 2, sender: 'Su Su',     avatar: 'SS', text: "Yes! I've prepared the slides for the presentation.",      time: '09:05 AM', date: '2026-06-07' },
  { id: 3, sender: 'Nay Lin',   avatar: 'NL', text: 'The venue is confirmed. See you all at 10 AM!',           time: '09:10 AM', date: '2026-06-07' },
  { id: 4, sender: 'Mya Mya',   avatar: 'MM', text: "Don't forget to bring your membership cards.",            time: '09:15 AM', date: '2026-06-07' },
  { id: 5, sender: 'Zaw Win',   avatar: 'ZW', text: 'Will the sports day schedule be shared beforehand?',      time: '09:22 AM', date: '2026-06-07' },
];

let nextMemberId  = 7;
let nextTaskId    = 7;
let nextMessageId = 6;

// ── Stats ────────────────────────────────────────────────────────
app.get('/api/stats', (req, res) => {
  res.json({
    totalMembers:    members.length,
    activeMembers:   members.filter(m => m.status === 'Active').length,
    totalTasks:      tasks.length,
    completedTasks:  tasks.filter(t => t.status === 'done').length,
    inProgressTasks: tasks.filter(t => t.status === 'inprogress').length,
    pendingTasks:    tasks.filter(t => t.status === 'todo').length,
    totalMessages:   messages.length,
  });
});

// ── Members ──────────────────────────────────────────────────────
app.get('/api/members', (req, res) => res.json(members));

app.post('/api/members', (req, res) => {
  const member = { id: nextMemberId++, joinDate: new Date().toISOString().split('T')[0], ...req.body };
  members.push(member);
  res.status(201).json(member);
});

app.put('/api/members/:id', (req, res) => {
  const idx = members.findIndex(m => m.id === parseInt(req.params.id));
  if (idx === -1) return res.status(404).json({ error: 'Not found' });
  members[idx] = { ...members[idx], ...req.body };
  res.json(members[idx]);
});

app.delete('/api/members/:id', (req, res) => {
  members = members.filter(m => m.id !== parseInt(req.params.id));
  res.json({ success: true });
});

// ── Tasks ────────────────────────────────────────────────────────
app.get('/api/tasks', (req, res) => res.json(tasks));

app.post('/api/tasks', (req, res) => {
  const task = { id: nextTaskId++, ...req.body };
  tasks.push(task);
  res.status(201).json(task);
});

app.put('/api/tasks/:id', (req, res) => {
  const idx = tasks.findIndex(t => t.id === parseInt(req.params.id));
  if (idx === -1) return res.status(404).json({ error: 'Not found' });
  tasks[idx] = { ...tasks[idx], ...req.body };
  res.json(tasks[idx]);
});

app.delete('/api/tasks/:id', (req, res) => {
  tasks = tasks.filter(t => t.id !== parseInt(req.params.id));
  res.json({ success: true });
});

// ── Messages ─────────────────────────────────────────────────────
app.get('/api/messages', (req, res) => res.json(messages));

app.post('/api/messages', (req, res) => {
  const msg = {
    id: nextMessageId++,
    time: new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' }),
    date: new Date().toISOString().split('T')[0],
    ...req.body,
  };
  messages.push(msg);
  res.status(201).json(msg);
});

// ── Start ─────────────────────────────────────────────────────────
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`\n  Thuriban Club Mgm  |  http://localhost:${PORT}\n`);
});
